//program to demonstrate creation of a user-defined thread by extends from Thread class

package com.ford.threads;

class MyThread extends Thread {

	@Override
	public void run() {

		for (int i = 1; i <= 10; i++) {

			System.out.println("number is:" + i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
	}
}

public class CustomThreadDemo1 {

	public static void main(String[] args) {

		MyThread obj = new MyThread();

		obj.start();

	}

}
