//program to demonstrate producer-consumer problem

package com.ford.threads;

class MedicalShop {

	private int stock;

	public void produceStock(int stock) {
		this.stock = stock;
		System.out.println("producer produced stock: " + stock);
	}

	public void consumerStock(int stock) {
		System.out.println("consumer consumed stock: " + stock);
		stock = 0;
	}
}

class ShopFactory {
	private static MedicalShop shop;

	public static MedicalShop getShop() {
		if (shop == null) {
			shop = new MedicalShop();
		}

		return shop;
	}
}

class Producer extends Thread {

	private MedicalShop shop;

	public Producer() {
		this.shop = ShopFactory.getShop();
	}

	public void run() {
		try {
			for (int i = 1; i <= 10; i++) {
				shop.produceStock(i);
				Thread.sleep(2000);
			}
		} catch (InterruptedException ie) {
			System.out.println("exception is:" + ie.getMessage());
		}
	}

}

class Consumer extends Thread {

	private MedicalShop shop;

	public Consumer() {
		this.shop = ShopFactory.getShop();
	}

	public void run() {
		try {
			for (int i = 1; i <= 10; i++) {
				shop.consumerStock(i);
				Thread.sleep(2000);
			}
		} catch (InterruptedException ie) {
			System.out.println("exception is:" + ie.getMessage());
		}
	}

}

public class InterThreadComm7 {

	public static void main(String[] args) {

		Producer p1 = new Producer();
		p1.start();

		Consumer c1 = new Consumer();
		c1.start();

	}
}
