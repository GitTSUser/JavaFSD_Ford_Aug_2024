//program to create multiple threads
package com.ford.threads;

class ThreadOne extends Thread {

	public void run() {

		for (int i = 1; i <= 10; i++) {
			System.out.println(Thread.currentThread().getName() + "-- num is:" + i);

			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

class ThreadTwo extends Thread {

	public void run() {

		for (int i = 10; i >= 1; i--) {
			System.out.println(Thread.currentThread().getName() + "-- num is(r):" + i);

			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

public class MultipleThreadsDemo4 {

	public static void main(String[] args) {

		ThreadOne t1 = new ThreadOne();
		t1.setPriority(4);
		ThreadTwo t2 = new ThreadTwo();
		t2.setPriority(10);

		t1.start();
		t2.start();

	}
}
