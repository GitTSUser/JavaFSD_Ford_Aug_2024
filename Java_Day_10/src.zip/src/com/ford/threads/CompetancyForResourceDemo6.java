package com.ford.threads;

class Printer {
/*
	public synchronized void printFile(String fileName) {
		try {
			System.out.println("printer started printing file :" + fileName);

			Thread.sleep(400);

			System.out.println("printer completed printing file :" + fileName);
		} catch (InterruptedException ie) {
			System.out.println("excepiton is:" + ie.getLocalizedMessage());
		}
	}
	*/

	public void printFile(String fileName) {
		try {

			synchronized (this) {
				System.out.println("printer started printing file :" + fileName);

				Thread.sleep(1400);

				System.out.println("printer completed printing file :" + fileName);
			}
		} catch (InterruptedException ie) {
			System.out.println("excepiton is:" + ie.getLocalizedMessage());
		}
	}
}

class PrinterFactory {

	private static Printer printer;

	public static Printer getPrinter() {

		if (printer == null) {

			printer = new Printer();
		}
		return printer;
	}

}

class Lappy extends Thread {

	private String fileName;
	private static Printer printer;

	static {
		printer = PrinterFactory.getPrinter();
	}

	public Lappy(String fileName) {
		this.fileName = fileName;
	}

	public void run() {
		printer.printFile(fileName);
	}
}
public class CompetancyForResourceDemo6 {
	public static void main(String[] args) {
		Lappy l1 = new Lappy("Abc.txt");
		l1.start();
		Lappy l2 = new Lappy("Xyz.txt");
		l2.start();
		Lappy l3 = new Lappy("Mnc.txt");
		l3.start();
	}
}