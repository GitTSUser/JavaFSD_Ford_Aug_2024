//program to demonstrate creation of custom thread by implementing Runnable interface

package com.ford.threads;

public class CustomThreadDemo3 {
	public static void main(String[] args) {

		Runnable myRunnable = () -> {
			for (int i = 1; i <= 20; i++) {
				if (i % 2 != 0) {
					System.out.println("odd num is:" + i);
				}
				try {
					Thread.sleep(250);
				} catch (InterruptedException ie) {
					System.out.println("exception is:" + ie.getMessage());
				}
			}
		};

		Thread t = new Thread(myRunnable);
		t.start();
	}
}
