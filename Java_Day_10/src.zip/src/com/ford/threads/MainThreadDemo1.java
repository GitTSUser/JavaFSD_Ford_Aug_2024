//program to demonstrate display the details of main thread
package com.ford.threads;

public class MainThreadDemo1 {

	public static void main(String[] args) {

		Thread currentThread = Thread.currentThread();

		System.out.println("currentThread is:" + currentThread);
		System.out.println("current thread id:" + currentThread.getId());
		System.out.println("current thread name:" + currentThread.getName());
		System.out.println("current thread priority:" + currentThread.getPriority());
		System.out.println("current thread group:" + currentThread.getThreadGroup().getName());

		System.out.println("active threads in current group:" + currentThread.getThreadGroup().activeCount());

		currentThread.setPriority(10);
		currentThread.setName("FordMainThread");
		System.out.println("new thread name:" + currentThread.getName());
		System.out.println("new thread priority:" + currentThread.getPriority());

		System.out.println("currentThread is:" + currentThread);

	}

}
