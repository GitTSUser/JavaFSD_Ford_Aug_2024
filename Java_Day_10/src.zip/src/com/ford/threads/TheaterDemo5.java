package com.ford.threads;

class Theater extends Thread {

	private String name;

	private int ticketNo;

	public Theater(String name) {
		this.name = name;

	}

	public int issueTicket(String name) {
		this.ticketNo = (int) Math.abs(Math.random() * 12345);
		System.out.println("ticket issued to " + name + " ticket no is:" + ticketNo);
		return ticketNo;
	}

	public void cutTicket(String name, int ticket) {
		System.out.println("ticket cut to " + name);
	}

	public void showSeat(String name, int ticket) {
		System.out.println("seat shown to " + name + " with ticket:" + ticket);

	}

	public void run() {

		try {
			int issuedTicket = issueTicket(this.name);
			Thread.sleep(200);
			cutTicket(this.name, issuedTicket);
			Thread.sleep(100);
			showSeat(this.name, issuedTicket);
		} catch (InterruptedException ie) {
			System.out.println("exception is:" + ie.getMessage());
		}
	}

}

public class TheaterDemo5 {

	public static void main(String[] args) throws InterruptedException {

		String[] customers = { "arun", "sumanth", "Vihaan", "Urvasi", "roja", "raman", "pooja" };

		for (String customer : customers) {
			Theater theater = new Theater(customer);
			theater.start();
			Thread.sleep(350);
		}

	}
}
