//program to demonstrate creation of custom thread by implementing Runnable interface

package com.ford.threads;

class MyRunnable implements Runnable {
	@Override
	public void run() {

		for (int i = 1; i <= 20; i++) {
			if (i % 2 == 0) {
				System.out.println("even num is:" + i);
			}
			try {
				Thread.sleep(250);
			} catch (InterruptedException ie) {
				System.out.println("exception is:" + ie.getMessage());
			}
		}
	}
}
public class CustomThreadDemo2 {
	public static void main(String[] args) {

		MyRunnable myRunnable = new MyRunnable();
		Thread t = new Thread(myRunnable);
		t.start();
	}
}
