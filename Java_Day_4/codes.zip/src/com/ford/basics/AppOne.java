//program to count the no.of factors of a given number N

package com.ford.basics;

public class AppOne {

	public static long findFactors(long n) {

		long cnt = 0;
		long startTime=System.currentTimeMillis();
		
		System.out.print("factors:");
		for (int i = 1; i <= n; i++) {
			if (n % i == 0) {
				System.out.print(i+" ");
			cnt++;
			}
		}

		long endTime=System.currentTimeMillis();
		
		System.out.println("\nTotal time taken is:"+(endTime-startTime)+" ms");
		return cnt;

	}

	public static void main(String args[]) {
		
		long result = findFactors(2400000000L);
		System.out.println();
		System.out.println("No.of factors is:" + result);
	}

}
