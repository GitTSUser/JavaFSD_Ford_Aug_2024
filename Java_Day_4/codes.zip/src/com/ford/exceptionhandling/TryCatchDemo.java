//program to demonstrate try-catch
package com.ford.exceptionhandling;

class Calculation {

	public int method2(int a, int b) {
		int result = 0;
		try {
			result = a / b;
		} catch (ArithmeticException exception) {
			System.out.println("exception is:" + exception.getMessage());
		}
		return result;
	}

	public int method1(int x, int y) {

		return method2(x, y);
	}

}

public class TryCatchDemo {

	public static void main(String[] args) {

		System.out.println("program begins");
		Calculation cal = new Calculation();
		int r = cal.method1(10, 0);
		System.out.println("result is:" + r);

		System.out.println("program ends");
	}

}