
//program to demonstrate how to store objects into an array
package com.ford.arrays;

import java.util.ArrayList;

class Student {

	private int id;
	private String name;
	private String branch;
	private int yearOfStudy;

	public Student(int id, String name, String branch, int yearOfStudy) {
		this.id = id;
		this.name = name;
		this.branch = branch;
		this.yearOfStudy = yearOfStudy;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public int getYearOfStudy() {
		return yearOfStudy;
	}

	public void setYearOfStudy(int yearOfStudy) {
		this.yearOfStudy = yearOfStudy;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", branch=" + branch + ", yearOfStudy=" + yearOfStudy + "]";
	}

}

public class ArrayDemo2 {

	public static int countStudentsInBranch(Student[] students, String branch) {

		int cnt = 0;

		for (Student st : students) {

			if (st.getBranch().equals(branch)) {
				cnt++;
			}
		}
		return cnt;
	}

	private static Student[] getStudentsInSameYear(Student[] students, int yearOfStudy) {

		int i = 0;
		ArrayList<Student> studList = new ArrayList<>();

		for (Student st : students) {

			if (st.getYearOfStudy() == yearOfStudy) {
				studList.add(st);
			}
		}

		Student[] resultArray = new Student[studList.size()];

		for (Student st : studList) {
			resultArray[i++] = st;
		}

		return resultArray;
	}

	public static void main(String[] args) {

		// create 8 student objects

		Student s1 = new Student(1001, "prasanth", "CSE", 3);
		Student s2 = new Student(1002, "sushanth", "EEE", 3);
		Student s3 = new Student(1003, "prasadh", "CSE", 1);
		Student s4 = new Student(1004, "mohan", "MECH", 2);
		Student s5 = new Student(1005, "vivek", "CSE", 3);
		Student s6 = new Student(1006, "lokesh", "IT", 2);
		Student s7 = new Student(1007, "muhesh", "EEE", 3);
		Student s8 = new Student(1008, "rakesh", "IT", 2);

		Student[] studArray = { s1, s2, s3, s4, s5, s6, s7, s8 };

		// count the no.of students in CSE branch
		int result = countStudentsInBranch(studArray, "IIT");

		System.out.println("No.of students in IIT:" + result);

		// find the students who are in yearOfStudy
		Student[] sameYearStudents = getStudentsInSameYear(studArray, 2);

		System.out.println("---Students in Same YearOfStudy---");

		for (Student st : sameYearStudents) {
			System.out.println(st);
		}
	}
}