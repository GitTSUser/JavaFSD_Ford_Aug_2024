package com.ford.oops.inheritance;

class A {

	int x,y;
	public A() {
		
	}
	public A(int x,int y) {
		super();
		this.x=x;
		this.y=y;
		System.out.println("constructor A() called");
	}

}

class B extends A {

	public B() {
		super();
		System.out.println("Constructor B() called");
	}
}

class C extends B {
	public C() {
		super();
		System.out.println("Constructor C() called");
	}

}

public class SuperUse {

	public static void main(String[] args) {

		C c = new C();

	}
}
