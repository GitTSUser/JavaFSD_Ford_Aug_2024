//program to demonstrate has-a relationship in inheritance
package com.ford.oops.inheritance;

import java.util.Arrays;

class Doctor {

	private int regNo;
	private String name;
	private String specialized;

	public Doctor(int regNo, String name, String specialized) {
		super();
		this.regNo = regNo;
		this.name = name;
		this.specialized = specialized;
	}

	public int getRegNo() {
		return regNo;
	}

	public String getName() {
		return name;
	}

	public String getSpecialized() {
		return specialized;
	}

	@Override
	public String toString() {
		return "Doctor [regNo=" + regNo + ", name=" + name + ", specialized=" + specialized + "]";
	}

}

class Patient {

	private int rxNo;
	private String name;
	private String diagnosed;
	private boolean isAssigedDoctor;

	public Patient(int rxNo, String name, String diagnosed, boolean isAssigedDoctor) {
		super();
		this.rxNo = rxNo;
		this.name = name;
		this.diagnosed = diagnosed;
		this.isAssigedDoctor = isAssigedDoctor;
	}

	public int getRxNo() {
		return rxNo;
	}

	public String getName() {
		return name;
	}

	public String getDiagnosed() {
		return diagnosed;
	}

	public boolean isAssigedDoctor() {
		return isAssigedDoctor;
	}

	@Override
	public String toString() {
		return "Patient [rxNo=" + rxNo + ", name=" + name + ", diagnosed=" + diagnosed + ", isAssigedDoctor="
				+ isAssigedDoctor + "]";
	}

}

class Hospital {

	private int regNo;
	private String name;
	private Doctor doctor;
	private Patient[] patients;

	public Hospital(int regNo, String name) {
		super();
		this.regNo = regNo;
		this.name = name;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public void setPatients(Patient[] patients) {
		this.patients = patients;
	}

	public int getRegNo() {
		return regNo;
	}

	public String getName() {
		return name;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public Patient[] getPatients() {
		return patients;
	}

	@Override
	public String toString() {
		return "Hospital [regNo=" + regNo + ", name=" + name + ", doctor=" + doctor + ", patients="
				+ Arrays.toString(patients) + "]";
	}
}

public class HasArelationDemo {

	public static void main(String[] args) {

		Doctor doctor = new Doctor(445566, "Tarun", "Cardiology");

		Patient p1 = new Patient(7777771, "raman", "fever", false);
		Patient p2 = new Patient(7777772, "suman", "headache", true);

		Patient[] patients = { p1, p2 };

		Hospital hospital = new Hospital(12345, "Apollo Hospitals");
		hospital.setDoctor(doctor);
		hospital.setPatients(patients);

		System.out.println(hospital.toString());

	}
}