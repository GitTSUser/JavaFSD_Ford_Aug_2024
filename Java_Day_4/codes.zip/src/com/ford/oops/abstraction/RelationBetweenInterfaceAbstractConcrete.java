//program to demonstrate the order of inheritance heierarchy with interfaces,abstract class and concrete classes
package com.ford.oops.abstraction;

interface Animal {
	void eat();
	void move();
	void sleep();
}

abstract class AbstractAnimal implements Animal {

	@Override
	public void eat() {
		System.out.println("animal eats food");
	}

	@Override
	public void sleep() {
		System.out.println("animal sleeps");
	}
}

class Snake extends AbstractAnimal {

	@Override
	public void move() {
		System.out.println("snake crawls on the ground");
	}

}

class Fish extends AbstractAnimal {

	@Override
	public void move() {

		System.out.println("fish swims in water");

	}

}

class Bird extends AbstractAnimal {

	@Override
	public void move() {
		System.out.println("bird flies in sky");
	}

	public void sing() {
		System.out.println("bird singing a song::ding dong bell");
	}	
}

class AnimalTrainer {

	// implemented the concept of method over loading
	/*
	 * public static void train(Bird bird) {
	 * 
	 * System.out.println("trainer giving training to bird"); bird.move();
	 * System.out.println("trainer completed training to bird"); }
	 * 
	 * public static void train(Fish fish) {
	 * 
	 * System.out.println("trainer giving training to fish"); fish.move();
	 * System.out.println("trainer completed training to fish"); }
	 * 
	 * public static void train(Snake snake) {
	 * 
	 * System.out.println("trainer giving training to snake"); snake.move();
	 * System.out.println("trainer completed training to snake"); }
	 */

	public static void train(Animal animal) {

		System.out.println("trainer giving training animal");
		animal.move();
		if(animal instanceof Bird) {
			Bird b=(Bird)animal;
			b.sing();
		}
		System.out.println("trainer completed training to animal");

	}
}

public class RelationBetweenInterfaceAbstractConcrete {

	public static void main(String[] args) {

		Animal animal;
		Bird bird = new Bird();
		Fish fish = new Fish();
		Snake snake = new Snake();

		AnimalTrainer.train(bird);
		System.out.println("-------------------");
		AnimalTrainer.train(fish);
		System.out.println("---------------------");
		AnimalTrainer.train(snake);

	}
}