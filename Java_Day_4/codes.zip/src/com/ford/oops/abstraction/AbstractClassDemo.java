//program to demonstrate abstract class and its implementation

package com.ford.oops.abstraction;

abstract class SBIBank {

	private String branch;
	private String regNo;
	private String location;
	

	public SBIBank(String branch, String regNo, String location) {
		this.branch = branch;
		this.regNo = regNo;
		this.location = location;
	}

	public abstract double findInterest(double amount);

	public String bankInfo() {
		return this.branch + " " + this.regNo + " " + this.location;
	}
}

class SBHBank extends SBIBank{

	public SBHBank(String branch, String regNo, String location) {
		super(branch, regNo, location);
	}

	public double findInterest(double amount) {
		if (amount < 10000) {
			return 0.0;
		} else if (amount >= 10000 && amount <= 250000) {
			return 3.5;
		} else {
			return 6.0;
		}
	}

	
}

class SBCBank extends SBIBank{

	public SBCBank(String branch, String regNo, String location) {
		super(branch, regNo, location);
	}

	public double findInterest(double amount) {
		if (amount < 100000) {
			return 0.0;
		} else if (amount >= 100000 && amount <= 500000) {
			return 5.5;
		} else {
			return 7.0;
		}
	}
}

public class AbstractClassDemo {

	public static void main(String[] args) {

		SBCBank bank = new SBCBank("SBC0001","123456","Karapakkam");
		System.out.println(bank.bankInfo());
		
		double roi=bank.findInterest(650000);
		System.out.println("roi is:"+roi);
	}
}