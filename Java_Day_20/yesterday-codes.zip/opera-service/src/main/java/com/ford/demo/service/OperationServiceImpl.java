package com.ford.demo.service;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OperationServiceImpl implements IOperationService {


    @Override
    public int performOperation(int a, int b, String operation) {

        if(operation.contains("add")){
            return a+b;
        }else if(operation.contains("sub")){
            return a-b;
        }else if(operation.contains("mul")){
            return a*b;
        }else if(operation.contains("div")){
            return a/b;
        }
        return 0;
    }

    @Override
    public List<String> getOperationsDetails() {
        List<String> operationList=List.of("add","sub","mul","div");

        return operationList;
    }
}
