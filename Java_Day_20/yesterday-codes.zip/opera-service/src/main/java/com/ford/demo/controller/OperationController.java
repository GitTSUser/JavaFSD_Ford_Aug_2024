package com.ford.demo.controller;

import com.ford.demo.service.IOperationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class OperationController {

    @Autowired
    IOperationService operationService;

    @PostMapping("/operations")
    public ResponseEntity<String> performOperation(@RequestParam("op1") int x, @RequestParam("op2") int y, @RequestParam("operation") String operation) {

        int result = operationService.performOperation(x, y, operation);

        if (operation.contains("add")) {
            return new ResponseEntity<String>("Addition is:" + result, HttpStatus.OK);
        } else if (operation.contains("sub")) {
            return new ResponseEntity<>("Subtraction is:" + result, HttpStatus.OK);
        } else if (operation.contains("mul")) {
            return new ResponseEntity<>("Multiplication is:" + result, HttpStatus.OK);
        } else if (operation.contains("div")) {
            return new ResponseEntity<>("Division is:" + result, HttpStatus.OK);
        }
        return new ResponseEntity<>("Operation invalid!", HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/operations")
    public ResponseEntity<List<String>> findOperationTypes() {

        List<String> operations = operationService.getOperationsDetails();

        return new ResponseEntity<>(operations, HttpStatus.OK);
    }
}