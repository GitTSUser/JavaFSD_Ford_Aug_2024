package com.ford.demo.service;

import java.util.List;

public interface IOperationService {

    public int performOperation(int a, int b, String operation);


    List<String> getOperationsDetails();
}
