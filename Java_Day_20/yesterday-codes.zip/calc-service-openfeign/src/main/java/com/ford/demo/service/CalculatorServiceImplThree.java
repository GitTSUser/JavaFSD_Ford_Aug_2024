package com.ford.demo.service;

import com.ford.demo.model.Calculator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CalculatorServiceImplThree implements ICalculatorService{


    @Autowired
    private APIClient apiClient;

    @Override
    public ResponseEntity<String> performOperation(int x, int y, String operation) {
        return apiClient.calculate(x,y,operation);
    }

    @Override
    public ResponseEntity<List<String>> getCalculationTypes() {
        return apiClient.calculateTypes();
    }
}
