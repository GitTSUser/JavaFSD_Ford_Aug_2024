package com.ford.demo.service;

import com.ford.demo.model.Calculator;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(url = "http://localhost:9091/OperaService/", value = "OPERA-SERVICE")
public interface APIClient {

    @PostMapping("/api/operations")
    public ResponseEntity<String> calculate(@RequestParam("op1")int op1, @RequestParam("op2")int op2, @RequestParam("operation")String operation);

    @GetMapping("/api/operations")
    public ResponseEntity<List<String>> calculateTypes();
}
