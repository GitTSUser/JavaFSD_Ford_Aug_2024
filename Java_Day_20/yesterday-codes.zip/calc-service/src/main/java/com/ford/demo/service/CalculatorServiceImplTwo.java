package com.ford.demo.service;

import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CalculatorServiceImplTwo implements ICalculatorService {


    @Autowired
    private WebClient webClient;

    @Override
    public ResponseEntity<String> performOperation(int x, int y, String operation) {
        ResponseEntity<String> response = webClient.post()
                .uri(uriBuilder -> uriBuilder
                        .path("/OperaService/api/operations")
                        .queryParam("op1", x)
                        .queryParam("op2", y)
                        .queryParam("operation", operation) // Fix the query param name here
                        .build())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .retrieve()
                .toEntity(String.class)
                .block();

        return response;
    }


    @Override
    public ResponseEntity<List<String>> getCalculationTypes() {

        String url = "/OperaService/api/operations";

        ResponseEntity<List<String>> responseList = webClient.get().uri(urlBuilder ->
                urlBuilder.path(url).build()
        ).retrieve().toEntity(new ParameterizedTypeReference<List<String>>() {
        }).block();

        return responseList;
    }
}
