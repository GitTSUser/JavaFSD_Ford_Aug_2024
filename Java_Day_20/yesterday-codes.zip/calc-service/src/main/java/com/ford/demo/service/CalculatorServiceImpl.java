package com.ford.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class CalculatorServiceImpl implements ICalculatorService {


    @Autowired
    private RestTemplate restTemplate;

    @Override
    public ResponseEntity<String> performOperation(int x, int y, String operation) {

        String url = String.format("http://localhost:9091/OperaService/api/operations?op1=%d&op2=%d&operation=%s", x, y, operation);

        ResponseEntity<String> response = restTemplate.postForEntity(url, null, String.class);

        return response;
    }

    @Override
    public ResponseEntity<List<String>> getCalculationTypes() {

        String url = "http://localhost:9091/OperaService/api/operations";

        ResponseEntity<List<String>> responseList = restTemplate.exchange(url, HttpMethod.GET, null, new ParameterizedTypeReference<List<String>>() {
        });

        return responseList;
    }
}
