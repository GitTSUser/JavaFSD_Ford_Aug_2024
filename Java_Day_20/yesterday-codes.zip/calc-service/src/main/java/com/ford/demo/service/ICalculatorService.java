package com.ford.demo.service;

import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ICalculatorService {

    public ResponseEntity<String> performOperation(int x,int y,String operation);

    public ResponseEntity<List<String>>  getCalculationTypes();
}
