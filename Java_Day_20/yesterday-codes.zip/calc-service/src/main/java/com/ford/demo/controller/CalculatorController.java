package com.ford.demo.controller;

import com.ford.demo.model.Calculator;
import com.ford.demo.service.ICalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CalculatorController {

    @Autowired
    @Qualifier("calculatorServiceImplTwo")
    private ICalculatorService calculatorService;

    @PostMapping("/calc")
    public ResponseEntity<String> calculate(@RequestBody Calculator calculator) {
        ResponseEntity<String> result = calculatorService.performOperation(calculator.getOperand1(), calculator.getOperand2(), calculator.getOperation());
        return result;
    }

    @GetMapping("/calctypes")
    public ResponseEntity<List<String>> calculateTypes() {
        ResponseEntity<List<String>> result = calculatorService.getCalculationTypes();
        return result;
    }
}