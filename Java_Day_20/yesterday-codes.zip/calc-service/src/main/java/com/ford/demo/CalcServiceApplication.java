package com.ford.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class CalcServiceApplication {

   @Bean
    public RestTemplate getRestTemplate() {
        return new RestTemplate();
    }

    @Bean
    public WebClient getWebClient() {
       return WebClient.builder().baseUrl("http://localhost:9091").build();
    }

    public static void main(String[] args) {
        SpringApplication.run(CalcServiceApplication.class, args);
    }

}
