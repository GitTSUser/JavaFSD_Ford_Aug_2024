package com.ford.demo.service;

import com.ford.demo.model.Applicant;

public interface IVerifyService {

    public boolean verify(Applicant applicant);

}
