package com.ford.demo.controller;

import com.ford.demo.model.Applicant;
import com.ford.demo.service.IVerifyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class VerifyController {

    @Autowired
    private IVerifyService verifyService;


    @PostMapping("/verify")
    public ResponseEntity<String> verifyApplicantDetails(@RequestBody Applicant applicant){

        if(verifyService.verify(applicant)){
            return new ResponseEntity<>("Verified Successfully!", HttpStatus.OK);
        }
    return new ResponseEntity<>("Details are not Valid!",HttpStatus.BAD_REQUEST);
    }
}
