package com.ford.demo.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Applicant {

    private String name;
    private String company;
    private String designation;
    private double salary;
    private int age;
    private String gender;
    private double requestedAmount;
    private int yearsOfWorkExperience;
}