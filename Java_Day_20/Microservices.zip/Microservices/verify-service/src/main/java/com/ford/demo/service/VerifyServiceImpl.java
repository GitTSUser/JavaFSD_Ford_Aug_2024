package com.ford.demo.service;

import com.ford.demo.model.Applicant;
import org.springframework.stereotype.Service;

@Service
public class VerifyServiceImpl implements IVerifyService {

    @Override
    public boolean verify(Applicant applicant) {

        if (applicant.getAge() >= 18 && applicant.getAge() <= 50) {
            if (applicant.getDesignation().contains("dev")) {
                if (applicant.getSalary() >= 25000) {
                    return true;
                }
            }
        }

        return false;
    }
}
