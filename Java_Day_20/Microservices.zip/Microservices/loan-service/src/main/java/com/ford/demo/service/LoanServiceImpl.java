package com.ford.demo.service;

import com.ford.demo.model.Applicant;
import com.ford.demo.model.Loan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class LoanServiceImpl implements ILoanService{

    @Autowired
    RestTemplate restTemplate;

    @Override
    public boolean verifyDetails(Applicant applicant) {

    ResponseEntity<String> response= restTemplate.postForEntity("http://localhost:8082/VerifyService/api/verify",applicant,String.class);

    if(response.getBody().contains("Success") && response.getStatusCode()== HttpStatus.OK){
        return true;
    }
        return false;
    }

    @Override
    public Loan generateLoanDetails(Applicant applicant) {
        return null;
    }
}