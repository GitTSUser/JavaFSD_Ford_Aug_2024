package com.ford.demo.service;

import com.ford.demo.model.Applicant;
import com.ford.demo.model.Loan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class LoanServiceImplTwo implements ILoanService {

    @Autowired
    private WebClient webClient;

    @Override
    public boolean verifyDetails(Applicant applicant) {

        String response = webClient.post().uri("http://localhost:8082/VerifyService/api/verify")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(applicant).retrieve().bodyToMono(String.class).block();

        if (response.contains("Success")) {
            return true;
        }
        return false;
    }

    @Override
    public Loan generateLoanDetails(Applicant applicant) {
        return null;
    }
}