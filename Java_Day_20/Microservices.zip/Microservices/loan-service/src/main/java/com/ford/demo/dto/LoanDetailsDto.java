package com.ford.demo.dto;

import com.ford.demo.model.Applicant;
import com.ford.demo.model.Loan;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoanDetailsDto {

    private Loan loan;
    private Applicant applicant;
}
