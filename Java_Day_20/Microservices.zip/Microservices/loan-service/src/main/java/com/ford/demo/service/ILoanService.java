package com.ford.demo.service;

import com.ford.demo.dto.LoanDetailsDto;
import com.ford.demo.model.Applicant;
import com.ford.demo.model.Loan;

public interface ILoanService {

    public boolean verifyDetails(Applicant applicant);

    public Loan generateLoanDetails(Applicant applicant);

}
