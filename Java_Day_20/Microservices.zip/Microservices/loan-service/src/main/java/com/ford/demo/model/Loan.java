package com.ford.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Loan {

    private Integer loanNo;
    private String loanType;
    private double amount;
    private int emi;


}
