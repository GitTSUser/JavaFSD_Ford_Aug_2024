package com.ford.demo.controller;

import com.ford.demo.dto.LoanDetailsDto;
import com.ford.demo.model.Applicant;
import com.ford.demo.model.Loan;
import com.ford.demo.service.ILoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class LoanController {

    @Autowired
    @Qualifier("loanServiceImplTwo")
    private ILoanService loanService;

    @PostMapping("/loans")
    public LoanDetailsDto loanDetails(@RequestBody Applicant applicant) {

        if(loanService.verifyDetails(applicant)){
            LoanDetailsDto loanDetailsDto = new LoanDetailsDto();
            loanDetailsDto.setApplicant(applicant);
            Loan loan=new Loan();
            loan.setLoanNo((int) Math.abs(Math.random()*12345667));
            loan.setLoanType("HouseLoan");
            loan.setAmount(250000);
            loan.setEmi(24);
            loanDetailsDto.setLoan(loan);
            return loanDetailsDto;
        }

        return null;
    }
}