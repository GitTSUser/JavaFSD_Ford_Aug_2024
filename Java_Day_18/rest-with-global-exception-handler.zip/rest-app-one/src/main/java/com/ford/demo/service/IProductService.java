package com.ford.demo.service;

import com.ford.demo.model.Product;

import java.util.List;

public interface IProductService {

    public Product saveProduct(Product product);
    public Product getProduct(int id);
    public List<Product> getAllProducts();
    public boolean deleteProduct(int id);
}
