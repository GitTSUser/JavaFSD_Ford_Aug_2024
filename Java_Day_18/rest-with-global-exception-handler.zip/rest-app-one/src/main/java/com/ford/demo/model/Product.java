package com.ford.demo.model;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    @Min(value = 0, message = "Id must not be negative number")
    private Integer id;
    @Size(min=5,max = 20, message = "Name must be  between 2 to 100 chars length")
    @NotBlank(message = "Name must not be empty")
    private String name;
    @Size(min = 10, max=500, message = "description must be betwen 10 to 500 chars")
    @NotBlank(message = "description mut not be empty")
    private String description;
    @Min(value = 0,message = "price must be positive number")
    private Double price;
}