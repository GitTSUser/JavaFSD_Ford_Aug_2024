package com.ford.demo.repository;

import com.ford.demo.model.Product;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ProductRepository {

    private static Logger logger= LoggerFactory.getLogger(ProductRepository.class);
    private  static List<Product> productList;

    static{
        productList = new ArrayList<Product>();
        productList.add(new Product(100,"fan","fan runs at super speed",4500.25));
        productList.add(new Product(200,"chain","Gold chain give shine",65500.25));
        productList.add(new Product(300,"lappy","lappy from Ford for you",85000.25));
    }

    public Product addProduct(Product product){
        logger.info("ProductRepository::addProduct(product) method started");
        productList.add(product);
        logger.info("ProductRepository::addProduct(product) method finished");
        return product;
    }

    public Product getProduct(int id){
        logger.info("ProductRepository::getProduct(id) method started");
        for(Product product : productList){
            if(product.getId() == id) {
                logger.info("ProductRepository::getProduct(id) method ends");
                return product;
            }
        }
        logger.info("ProductRepository::getProduct(id) method finished");
        return null;
    }

    public List<Product> getProductList(){
        logger.info("ProductRepository::getProductList() method started");
        List<Product> productList2= productList;
        logger.info("ProductRepository::getProductList() method finished");
        return productList2;
    }

    public boolean deleteProduct(int id){
        for(Product product : productList){
            if(product.getId() == id) {
                productList.remove(product);
                return true;
            }
        }
        return false;
    }
}