package com.ford.demo.service;

import com.ford.demo.exception.ProductNotFoundException;
import com.ford.demo.model.Product;
import com.ford.demo.repository.ProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProductServiceImpl implements IProductService{

    private static Logger logger= LoggerFactory.getLogger(ProductServiceImpl.class);
    @Autowired
    private ProductRepository productRepository;



    @Override
    public Product saveProduct(Product product) {
        logger.info("ProductServiceImpl::saveProduct(product) method started");
        Product savedProduct= productRepository.addProduct(product);
        logger.info("ProductServiceImpl::saveProduct(product) method completed");
        return savedProduct;
    }

    @Override
    public Product getProduct(int id) {
        logger.info("ProductServiceImpl::getProduct(id) method started");
        Product product=null;
        try {
          product = productRepository.getProduct(id);
        }catch(ProductNotFoundException exception){
            logger.error("ProductServiceImpl::getProduct(id) Product not found Exception"+exception);
            throw exception;
        }
        logger.info("ProductServiceImpl::getProduct(id) method completed");
        return product;
    }

    @Override
    public List<Product> getAllProducts() {
        logger.info("ProductServiceImpl::getAllProducts() method started");
        List<Product> productList= productRepository.getProductList();
        logger.info("ProductServiceImpl::getAllProducts() method completed");
        return productList;
    }

    @Override
    public boolean deleteProduct(int id) {
        return productRepository.deleteProduct(id);
    }
}