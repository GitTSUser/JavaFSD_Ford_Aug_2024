package com.ford.demo.exception;


public class ProductNotFoundException extends  RuntimeException {

    private String exceptionMsg;

    public ProductNotFoundException(String exceptionMsg) {
        super(exceptionMsg);
        this.exceptionMsg = exceptionMsg;
    }

    @Override
    public String toString() {
        return "ProductNotFoundException{" +
                "exceptionMsg='" + exceptionMsg + '\'' +
                '}';
    }
}
