package com.ford.demo.exception;

public class InvalidProductToSaveException extends RuntimeException {

    private String exceptionMsg;
    public InvalidProductToSaveException(String string) {
        super(string);
        exceptionMsg = string;
    }

    @Override
    public String toString() {
        return "InvalidProductToSaveException{" +
                "exceptionMsg='" + exceptionMsg + '\'' +
                '}';
    }
}
