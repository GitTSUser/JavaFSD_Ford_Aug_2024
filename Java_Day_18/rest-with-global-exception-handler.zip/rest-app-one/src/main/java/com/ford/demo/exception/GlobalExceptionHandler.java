package com.ford.demo.exception;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;


@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(InvalidProductToSaveException.class)
    public ResponseEntity<CustomErrorResponse> handleInvalidProductException(InvalidProductToSaveException ex, HttpServletRequest request){
        logger.info("handleInvalidProductExcceptioin method called");
        CustomErrorResponse errorResponse=new CustomErrorResponse(LocalDateTime.now(),ex.getMessage(), 500,request.getServletPath());

        return new ResponseEntity(errorResponse,HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ProductNotFoundException.class)
    public ResponseEntity<CustomErrorResponse> handleProductNotFoundException(ProductNotFoundException ex, HttpServletRequest request){

        CustomErrorResponse errorResponse=new CustomErrorResponse(LocalDateTime.now(),ex.getMessage(), 500,request.getServletPath());
        return new ResponseEntity(errorResponse,HttpStatus.NOT_FOUND);
   }
}
