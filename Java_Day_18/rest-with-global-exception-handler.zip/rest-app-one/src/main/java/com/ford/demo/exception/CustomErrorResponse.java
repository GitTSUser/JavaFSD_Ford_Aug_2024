package com.ford.demo.exception;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class CustomErrorResponse {

    private LocalDateTime timestamp;
    private String message;
    private Integer status;
    private String path;

    public CustomErrorResponse(LocalDateTime timestamp, String message, Integer status, String path) {

        this.timestamp = timestamp;
        this.message = message;
        this.status = status;
        this.path = path;
    }

    @Override
    public String toString() {
        return "CustomErrorResponse{" +
                "timestamp=" + timestamp +
                ", message='" + message + '\'' +
                ", status=" + status +
                ", path='" + path + '\'' +
                '}';
    }
}