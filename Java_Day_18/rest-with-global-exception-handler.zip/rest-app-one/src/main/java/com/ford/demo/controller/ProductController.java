package com.ford.demo.controller;

import com.ford.demo.exception.InvalidProductToSaveException;
import com.ford.demo.model.Product;
import com.ford.demo.service.IProductService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@Slf4j
public class ProductController {

    @Autowired
    private IProductService productService;

    @PostMapping("/products")
    public ResponseEntity<Product> saveProduct(@RequestBody @Valid Product product, BindingResult bindingResult) {

        log.info("ProductController::saveProduct(product) method started");
        log.info("Product got to save is: {}",product);
        if (bindingResult.hasErrors()) {
            //bindingResult.getAllErrors().forEach(error -> logger.error(error.getDefaultMessage()));
            throw new InvalidProductToSaveException("invalid product details, cannot be saved.!");
        }
        Product saveProduct=productService.saveProduct(product);
        log.info("ProductController::saveProduct(product) method ends");
        return new ResponseEntity<>(saveProduct, HttpStatus.ACCEPTED);
   }

   @GetMapping("/products")
   public List<Product> getAllProducts(){
        log.info("ProductController:: getAllProducts() method started");
        List<Product> products=productService.getAllProducts();
        log.info("ProductController:: getAllProducts() method ends");
        return products;
   }

   @GetMapping("/products/{id}")
   public Product getProduct(@PathVariable Integer id) {
        log.info("ProductController:: getProduct(id) method started");
       Product product= productService.getProduct(id);
       log.info("ProductController:: getProduct(id) method ends");
       return product;
   }

   @DeleteMapping("/products/{id}")
   public String deleteProduct(Integer id) {
        if(productService.deleteProduct(id)){
        return "Product deleted Successfully";
        }
   return "Product is not found to delete";
   }
}