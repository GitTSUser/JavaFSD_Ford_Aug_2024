package com.ford.demo.service;

import com.ford.demo.model.Company;

import java.util.List;

public interface ICompanyService {

    public Company addCompany(Company company);
    public Company updateCompany(Company company);
    public List<Company> getAllCompanies();
    public Company getCompanyById(int id);
    public boolean deleteCompany(int id);
}
