package com.ford.demo;

import com.ford.demo.model.Company;
import com.ford.demo.service.ICompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CompanyController {


    @Autowired
    private ICompanyService companyService;

    @PreAuthorize("hasAnyRole('ADMIN','USER')")
    @GetMapping("/companies")
    public List<Company> getAllCompanies(){

        return companyService.getAllCompanies();

    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/companies")
    public Company addCompany(@RequestBody Company company){
        return companyService.addCompany(company);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/companies")
    public Company updateCompany(@RequestBody Company company){
        return companyService.updateCompany(company);
    }

    @GetMapping("/companies/{id}")
    public Company getCompanyById(@PathVariable int id){
        return companyService.getCompanyById(id);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/companies/{id}")
    public String  deleteCompanyById(@PathVariable int id){
        if(companyService.deleteCompany(id)){
            return "deleted";
        }
        return "error in delete";
    }
}