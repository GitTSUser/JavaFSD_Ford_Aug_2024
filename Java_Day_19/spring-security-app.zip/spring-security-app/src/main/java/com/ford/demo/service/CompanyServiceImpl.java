package com.ford.demo.service;

import com.ford.demo.model.Company;
import org.springframework.stereotype.Service;

import java.io.Serial;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class CompanyServiceImpl implements ICompanyService{


    private static List<Company> companies;
    static {
        companies = new ArrayList<Company>();
        companies.add(new Company(1001,"Ford","Karapakkam","Jim Farley"));
        companies.add(new Company(1002,"TCS","Navalur","K. Krithivasan"));
        companies.add(new Company(1003,"CTS","Koyambedu","Ravi Kumar S"));
    }

    @Override
    public Company addCompany(Company company) {
         companies.add(company);
         return company;
    }

    @Override
    public Company updateCompany(Company updatedCompany) {

        return updatedCompany;
    }


    @Override
    public List<Company> getAllCompanies() {
        return companies;
    }

    @Override
    public Company getCompanyById(int id) {
        for(Company company : companies){
            if(company.getRegNo()==id){
                return company;
            }
        };
        return null;
    }

    @Override
    public boolean deleteCompany(int id) {
        return false;
    }
}
