package com.ford.demo.controller;

import com.ford.demo.model.Product;
import com.ford.demo.service.IProductService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api")
public class ProductController {

    @Autowired
    private IProductService productService;

    @PostMapping("/products")
    public Product saveProduct(@RequestBody Product product) {
        log.info(this.getClass().getName() + " saveProduct(product) called");
        return productService.addProduct(product);
    }

    @GetMapping("/products/{id}")
    public Product getProductById(@PathVariable("id") int id) {
        return productService.getProduct(id);
    }

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        log.info(this.getClass().getName() + " getAllProducts() called");
        return productService.getAllProducts();
    }

    @PutMapping("/products")
    public Product updateProduct(@RequestBody Product product) {
        return productService.updateProduct(product);
    }

    @DeleteMapping("/products/{id}")
    public String deleteProduct(@PathVariable("id") int id) {
        productService.deleteProduct(id);
        return "product deleted with id:"+id;
    }
}