package com.ford.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityJwtBasedApplicationTests {

    @Test
    void contextLoads() {
    }

}
