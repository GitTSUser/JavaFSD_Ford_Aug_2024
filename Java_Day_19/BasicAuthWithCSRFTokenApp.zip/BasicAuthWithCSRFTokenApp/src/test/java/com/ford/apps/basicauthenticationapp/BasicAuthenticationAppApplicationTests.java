package com.ford.apps.basicauthenticationapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicAuthenticationAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
