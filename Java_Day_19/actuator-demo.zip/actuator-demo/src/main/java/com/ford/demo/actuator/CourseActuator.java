package com.ford.demo.actuator;

import lombok.Data;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Endpoint(id="mycourse")
public class CourseActuator {

    @Data
    static  class CourseAppStatus{

        private String status;
        private String portNo;

        public CourseAppStatus(String status,String portNo) {
            this.status=status;
            this.portNo=portNo;
        }
    }


    @ReadOperation(produces = "application/json")
    public CourseAppStatus getCourseAppStatus() {
        boolean result=getCourseAppCurrentStatus();
        if(result){
            return new CourseAppStatus("UP","8080");
        }
        return new CourseAppStatus("DOWN","8080");
    }

    public boolean getCourseAppCurrentStatus(){
        return false; //app is running
    }
}