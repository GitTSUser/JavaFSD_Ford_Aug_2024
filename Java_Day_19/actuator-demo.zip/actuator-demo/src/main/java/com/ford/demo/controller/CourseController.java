package com.ford.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CourseController {


    @GetMapping("/courses")
    public List<String> courseDetails(){

        return List.of("Java FSD","UX/UI design","AI/ML","Python FSD",".NET FSD");

    }

}
