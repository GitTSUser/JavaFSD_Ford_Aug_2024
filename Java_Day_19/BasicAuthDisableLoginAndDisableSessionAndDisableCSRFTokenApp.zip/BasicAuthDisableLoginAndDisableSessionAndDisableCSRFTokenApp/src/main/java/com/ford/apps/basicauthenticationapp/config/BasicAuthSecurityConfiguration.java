package com.ford.apps.basicauthenticationapp.config;

import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

/*
  here, we are disbling csrf token, form login and session management
   so that app runs without basic form login, session and csrf token
 */
@Configuration
public class BasicAuthSecurityConfiguration {

    @Bean
    SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http) throws Exception {
        http.authorizeRequests(
                authRequest -> {
                    authRequest.anyRequest().authenticated();
                }
        );
        http.sessionManagement(session-> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)); //disabled session
        //http.formLogin();   //disabled form login
        http.httpBasic();
        http.csrf().disable(); //disbled csrf token filter
        return http.build();
    }

}
