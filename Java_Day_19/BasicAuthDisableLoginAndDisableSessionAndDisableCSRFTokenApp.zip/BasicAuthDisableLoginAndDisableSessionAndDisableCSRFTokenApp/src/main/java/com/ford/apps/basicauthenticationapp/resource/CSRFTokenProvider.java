package com.ford.apps.basicauthenticationapp.resource;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api")
public class CSRFTokenProvider {

    @GetMapping("/csrf-token")
    public CsrfToken retreiveCSRFToken(HttpServletRequest httpRequest) {

        return (CsrfToken) httpRequest.getAttribute("_csrf");
    }
}
