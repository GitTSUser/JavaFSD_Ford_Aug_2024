package com.ford.demo.service;

import com.ford.demo.model.Customer;

import java.util.List;

public interface ICustomerService {

    public Customer addCustomer(Customer customer);
    public Customer getCustomer(int id);
    public List<Customer> getAllCustomers();
    public Customer updateCustomer(Customer customer);
    public void deleteCustomer(int id);
}
