package com.ford.demo.controller;

import com.ford.demo.model.Product;
import com.ford.demo.service.IProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ProductController {

    private static Logger logger= LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private IProductService productService;

    @PostMapping("/products")
    public Product saveProduct(@RequestBody Product product) {
        logger.info("ProductController::saveProduct(product) method started");
        logger.info("Product got to save is: {}",product);
        Product saveProduct=productService.saveProduct(product);
        logger.info("ProductController::saveProduct(product) method ends");
        return saveProduct;
   }

   @GetMapping("/products")
   public List<Product> getAllProducts(){
        logger.info("ProductController:: getAllProducts() method started");
        List<Product> products=productService.getAllProducts();
        logger.info("ProductController:: getAllProducts() method ends");
        return products;
   }

   @GetMapping("/products/{id}")
   public Product getProduct(@PathVariable Integer id) {
        logger.info("ProductController:: getProduct(id) method started");
       Product product= productService.getProduct(id);
       logger.info("ProductController:: getProduct(id) method ends");
       return product;
   }

   @DeleteMapping("/products/{id}")
   public String deleteProduct(Integer id) {
        if(productService.deleteProduct(id)){
        return "Product deleted Successfully";
        }
   return "Product is not found to delete";
   }
}