//program to demonstrate the hashset collection
package com.ford.collections;

import java.util.HashSet;
import java.util.Iterator;

public class SetDemo3 {

	public static void main(String[] args) {

		HashSet set = new HashSet();

		System.out.println("set size is:" + set.size());
		set.add(120);
		set.add("hello");
		set.add(2500.23);
		set.add(false);
		set.add('I');
		set.add("hello");
		set.add(120);

		System.out.println("set is:" + set);
		System.out.println("set size is:" + set.size());

		System.out.println("set elements are:");
		Iterator iterator=set.iterator();
		
		while(iterator.hasNext()) {
			System.out.println("element is:"+iterator.next());
		}
	}
}
