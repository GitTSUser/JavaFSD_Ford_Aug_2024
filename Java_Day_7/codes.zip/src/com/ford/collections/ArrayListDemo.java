//program demonstrate creation of an array list collection and storing hetero elemeents into it
package com.ford.collections;

import java.util.ArrayList;

public class ArrayListDemo {
	
	public static void main(String[] args) {
		
		ArrayList  list=new ArrayList();
		System.out.println("list size is:"+list.size());
		
		list.add(100); //int type   --->  list.add(new Integer(100));
		list.add("hello"); //string  --> list.add(new String("hello"));
		list.add(34900.20); //double --> list.add(new Double(34900.20));
		list.add(true); //boolean
		list.add('K'); //character
		
		System.out.println(list);
		
		System.out.println("list size is:"+list.size());		
		
		list.add(100);
		list.add("hello");
		System.out.println(list);
		System.out.println("list size is:"+list.size());
		System.out.println("find element at 4 th position is:"+list.get(4));

		System.out.println("list is:");
		for(int i=0;i<list.size();i++) {
			System.out.println("element is:"+list.get(i));
		}
		
		
		if(list.contains("hello")) {
			list.set(1, "Hi");
		}
		
		System.out.println("after update, list is:"+list);
		
		list.remove("Hi");
		
		System.out.println("after remove, list is:"+list);
		
		list.remove(new Integer(100));
		System.out.println("after 100 remove,list is:"+list);
		
		list.clear();
		
		System.out.println("removed all, list is:"+list);
	}
}