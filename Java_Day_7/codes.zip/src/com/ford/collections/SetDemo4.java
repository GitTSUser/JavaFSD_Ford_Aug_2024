//program to demonstrate the set doesn't accept duplicates and doesn't maintain order of elemenets

package com.ford.collections;

import java.util.HashSet;

public class SetDemo4 {

	public static void addDataIntoSet(HashSet<Integer> numSet) {

		numSet.add(100);
		numSet.add(200);
		numSet.add(300);
		numSet.add(400);

	}

	public static void main(String[] args) {

		HashSet<Integer> numSet = new HashSet<Integer>();

		System.out.println(numSet);

		addDataIntoSet(numSet);

		numSet.add(100);
		numSet.add(200);
		numSet.add(300);
		numSet.add(500);

		System.out.println(numSet);
		System.out.println("set has " + numSet.size() + " elements");
	}
}