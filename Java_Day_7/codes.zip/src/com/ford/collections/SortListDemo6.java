//program to demonstrate sort the list of elements

package com.ford.collections;

import java.util.ArrayList;
import java.util.Collections;

public class SortListDemo6 {

	public static void main(String[] args) {

		ArrayList<Integer> numList = new ArrayList<>();

		numList.add(100);
		numList.add(500);
		numList.add(200);
		numList.add(300);
		numList.add(60);

		System.out.println(numList);
		
		Collections.sort(numList);

		System.out.println(numList);

	}

}
