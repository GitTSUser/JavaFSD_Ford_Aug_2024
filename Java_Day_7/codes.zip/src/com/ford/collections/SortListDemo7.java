//program to demonstrate object ordering or sorting 
package com.ford.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Student implements Comparable<Student> {
	private int id;
	private String name;
	private String branch;

	public Student(int id, String name, String branch) {
		super();
		this.id = id;
		this.name = name;
		this.branch = branch;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", branch=" + branch + "]";
	}

	@Override
	public int compareTo(Student sObj) {

		if (this.getId() < sObj.getId()) {
			return -1;
		} else if (this.getId() > sObj.getId()) {
			return 1;
		}
		return 0;
	}
}

public class SortListDemo7 {

	private static void addStudents(ArrayList<Student> studentList) {

		Student s1 = new Student(1001, "arun", "CSE");
		Student s2 = new Student(1002, "varun", "IT");
		Student s3 = new Student(1005, "tarun", "CSE");
		Student s4 = new Student(1006, "charun", "EEE");
		Student s5 = new Student(1007, "karun", "IT");
		Student s6 = new Student(1008, "kumaran", "CSE");
		Student s7 = new Student(1004, "sharan", "MECH");
		Student s8 = new Student(1003, "sharon", "IT");

		studentList.add(s1);
		studentList.add(s2);
		studentList.add(s3);
		studentList.add(s4);
		studentList.add(s5);
		studentList.add(s6);
		studentList.add(s7);
		studentList.add(s8);

	}

	private static void printStudents(ArrayList<Student> studentList) {

		for (Student st : studentList) {
			System.out.println(st);
		}

	}

	public static void sortById(List<Student> studentList) {
		System.out.println("-----sort by Id-----");
		Collections.sort(studentList);
	}

	public static void main(String[] args) {
		ArrayList<Student> studentList = new ArrayList<>();
		addStudents(studentList);
		printStudents(studentList);
		sortById(studentList);
		printStudents(studentList);
	}
}