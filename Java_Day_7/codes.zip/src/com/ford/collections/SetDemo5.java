//program to demonstrate storing product objects into the set and verify them
package com.ford.collections;

import java.util.HashSet;

class Product {

	private int id;
	private String name;
	private double price;
	private String category;
	private int qty;

	public Product(int id, String name, double price, String category, int qty) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.category = category;
		this.qty = qty;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

	public String getCategory() {
		return category;
	}

	public int getQty() {
		return qty;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", category=" + category + ", qty=" + qty
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + qty;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (qty != other.qty)
			return false;
		return true;
	}

}

public class SetDemo5 {

	public static void addProducts(HashSet<Product> productSet) {
		Product p1 = new Product(1001, "fan", 2400.25, "electronics", 5);
		Product p2 = new Product(1002, "chair", 12400.25, "furniture", 10);
		Product p3 = new Product(1003, "lappy", 40000.25, "electronics", 15);
		Product p4 = new Product(1001, "fan", 2400.25, "electronics", 5);

		System.out.println("p1 hashCode is:" + p1.hashCode());
		System.out.println("p2 hashCode is:" + p2.hashCode());
		System.out.println("p3 hashCode is:" + p3.hashCode());
		System.out.println("p4 hashCode is:" + p4.hashCode());

		productSet.add(p1);
		productSet.add(p2);
		productSet.add(p3);
		productSet.add(p4);
	}

	public static void displayProducts(HashSet<Product> productSet) {

		for (Product product : productSet) {

			System.out.println(product);
		}

	}

	public static void main(String[] args) {

		HashSet<Product> productSet = new HashSet<Product>();
		addProducts(productSet);
		System.out.println("products in set are:" + productSet.size());
		displayProducts(productSet);
	}
}