//program to demonstrate storing generic type elements into ArrayList
package com.ford.collections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo2 {

	public static List<Integer> vowelCount(ArrayList<String> cityList) {

		List<Integer> counterList = new ArrayList<>();

		for (int i = 0; i < cityList.size(); i++) {

			char[] cityArr = cityList.get(i).toLowerCase().toCharArray();
			int cnt = 0;
			for (int j = 0; j < cityArr.length; j++) {
				if (cityArr[j] == 'a' || cityArr[j] == 'e' || cityArr[j] == 'i' || cityArr[j] == 'o'
						|| cityArr[j] == 'u') {
					cnt++;
				}
			}
			counterList.add(cnt);
		}

		return counterList;

	}

	public static void main(String[] args) {

		ArrayList<String> cityList = new ArrayList<String>();

		cityList.add("Chennai");
		cityList.add("Madhurai");
		cityList.add("Mumbai");
		cityList.add("Covai");
		// cityList.add(12000);

		System.out.println("cities are:" + cityList);
		List<Integer> countList = vowelCount(cityList);

		System.out.println("vowel are:" + countList);
	}

}
