package com.ford.generic;

class CustomArrayList<T> {

	Object arr[];
	int cnt = 0;
	int currentCapacity = 0;

	public CustomArrayList(int capacity) {
		arr = new Object[capacity];
		currentCapacity = capacity;
	}

	// Method to add an element to the array
	public void addElement(T t) {
		// Check if the array is full
		if (cnt < currentCapacity) {
			arr[cnt++] = t; // Add the element and increment the count
		} else {
			// If array is full, create a new array with double capacity
			currentCapacity = currentCapacity * 2;
			Object[] tempArr = new Object[currentCapacity];

			// Copy old elements to the new array
			for (int i = 0; i < arr.length; i++) {
				tempArr[i] = arr[i];
			}

			// Add the new element to the resized array
			tempArr[cnt++] = t;
			arr = tempArr; // Replace the old array with the new one
		}
	}

	// Method to display all the elements in the array
	public void getElements() {
		for (int i = 0; i < cnt; i++) {
			System.out.println("object is: " + arr[i]);
		}
	}
}

public class GenericClassDemo2 {

	public static void main(String[] args) {
		CustomArrayList<Integer> list = new CustomArrayList<>(3);

		// Adding elements to the custom list
		list.addElement(100);
		list.addElement(200);
		list.addElement(300);
		list.addElement(400);
		list.addElement(500);
		list.addElement(600);
		list.addElement(700);
		list.addElement(800);

		// Displaying the elements
		list.getElements();
	}
}
