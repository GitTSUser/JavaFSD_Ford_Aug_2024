//program to demonstrate creation of a generic class

package com.ford.generic;

class MyClass<T> {

	T t;

	public MyClass(T t) {
		this.t = t;
	}

	public T getElement() {
		return this.t;
	}
}

public class GenericClassDemo {

	public static void main(String[] args) {

		MyClass<Integer> num = new MyClass<Integer>(100);

		System.out.println("integer is:" + num.getElement());

		MyClass<String> name = new MyClass<String>("Varun Kumar");
		System.out.println("Name is:" + name.getElement());

		MyClass<Double> salary = new MyClass<Double>(45000.25);

		System.out.println("salary is:" + salary.getElement());
	}
}