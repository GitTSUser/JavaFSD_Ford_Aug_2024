//program to demonstrate generic method inside a non-generic class 
//and accepts generic type data as argument
package com.ford.generic;

class NonGenericClass {

	public <T> void displayElements(T[] t) {

		for (T ele : t) {
			System.out.println("element is:" + ele);
		}
	}
}

public class GenericMethodDemo {

	public static void main(String[] args) {

		NonGenericClass obj = new NonGenericClass();

		Integer[] intArr = { 1, 2, 3, 4, 5 };

		obj.displayElements(intArr);

		Double[] doubleArr = { 1.1, 2.2, 3.3, 4.4, 5.5 };

		obj.displayElements(doubleArr);

		Character[] charArr = { 'a', 'e', 'i', 'o', 'u' };

		obj.displayElements(charArr);

	}

}
