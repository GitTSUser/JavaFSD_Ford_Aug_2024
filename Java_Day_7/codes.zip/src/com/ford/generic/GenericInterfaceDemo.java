//program to demonstrate the generic interface implementation

package com.ford.generic;

interface Trainable<T> {

	public void train(T t);
}

class Student {
	private int rollNo;
	private String name;

	public Student(int rollNo, String name) {
		this.rollNo = rollNo;
		this.name = name;
	}

	@Override
	public String toString() {
		return this.rollNo + " " + this.name;
	}
}

class ItStudent extends Student {

	private String course;

	public ItStudent(int rollNo, String name, String course) {
		super(rollNo, name);
		this.course = course;
	}

	@Override
	public String toString() {
		return super.toString() + " " + this.course;
	}

}

class NonItStudent extends Student {

	private String project;

	public NonItStudent(int rollNo, String name, String project) {
		super(rollNo, name);
		this.project = project;
	}

	@Override
	public String toString() {
		return super.toString() + " " + this.project;
	}
}

class Trainer {
	private int rollNo;
	private String name;

	public Trainer(int rollNO, String name) {
		this.rollNo = rollNo;
		this.name = name;
	}

	public String toString() {
		return this.rollNo + " " + this.name;
	}

}

class ItTrainer extends Trainer implements Trainable<ItStudent> {
	private String techStack;

	public ItTrainer(int rollNo, String name, String techStack) {
		super(rollNo, name);
		this.techStack = techStack;
	}

	public String toString() {
		return super.toString() + " " + this.techStack;
	}

	@Override
	public void train(ItStudent st) {
		System.out.println("IT trainer delivers training to "+st);
	}

}

class NonItTrainer extends Trainer implements Trainable<NonItStudent>{

	private String projectStack;

	public NonItTrainer(int rollNo, String name, String projectStack) {
		super(rollNo, name);
		this.projectStack = projectStack;
	}

	public String toString() {
		return super.toString() + " " + this.projectStack;
	}

	@Override
	public void train(NonItStudent st) {
		System.out.println("NonItTrainer delivers training to "+st);
		
	}
}
public class GenericInterfaceDemo {
	public static void main(String[] args) {
		ItTrainer itTrainer=new ItTrainer(1001,"Arun","Java FSD");
		itTrainer.train(new ItStudent(100, "vishal(ITStudent)", "Java"));
		
		NonItTrainer nonItTrainer=new NonItTrainer(2001,"Rajan","Fitter");
		nonItTrainer.train(new NonItStudent(200,"Raman(Non-IT Student)","farming"));
		
		
		
		
	}
}
