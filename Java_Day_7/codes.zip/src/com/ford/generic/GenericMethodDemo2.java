package com.ford.generic;

import java.util.Arrays;
import java.util.List;

class NumberOnlyClass {
	
	//generic method with upperbound and accepts Number or its subtypes for(?)
	public <T> void displayNumberOrChildToNumberElements(List<? extends Number> t) {

		for (Object ele : t) {
			System.out.println("element is:" + ele);
		}
	}

	//generic method with lowerbound and accepts String or its supertypes for(?) 
	public <T> void displayStringOrParentToStringElements(List<? super String> t) {

		for (Object ele : t) {
			System.out.println("element is:" + ele);
		}
	}

	//generic method with unbounded type and accepts any type for (?)
	public <T> void displayAnyElementTypes(List<?> t) {

		for (Object ele : t) {
			System.out.println("element is:" + ele);
		}
	}
}
public class GenericMethodDemo2 {
	public static void main(String[] args) {
		NumberOnlyClass obj = new NumberOnlyClass();
		Integer[] intArr = { 1, 2, 3, 4, 5 };
		List<Integer> intList = Arrays.asList(intArr);
		obj.displayNumberOrChildToNumberElements(intList);

		System.out.println("------------------------");

		Double[] doubleArr = { 1.1, 2.2, 3.3, 4.4, 5.5 };
		List<Double> doubleList = Arrays.asList(doubleArr);
		obj.displayNumberOrChildToNumberElements(doubleList);

		System.out.println("------------------------");
		String[] strArr = { "Chennai", "Madhurai", "Covai", "Mumbai" };
		List<String> strList = Arrays.asList(strArr);
		obj.displayStringOrParentToStringElements(strList);

		Product p1 = new Product(100, "fan", 3400.20);
		Product p2 = new Product(200, "chair", 4500.25);
		List<Product> prodList = Arrays.asList(new Product[] { p1, p2 });
		obj.displayAnyElementTypes(prodList);

	}

}
