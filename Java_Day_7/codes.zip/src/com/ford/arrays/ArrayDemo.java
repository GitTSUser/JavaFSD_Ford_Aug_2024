//program to demonstrate creation of an array in java
package com.ford.arrays;

public class ArrayDemo {

	public static void main(String[] args) {

		// array declaration
		int marks[] = new int[6];

		System.out.println("no.of elements are:" + marks.length);

		// array initialization
		marks[0] = 12;
		marks[1] = 40;
		marks[2] = 50;
		marks[3] = 65;
		marks[4] = 55;
		marks[5] = 85;

		for (int i = 0; i < marks.length; i++) {

			System.out.print(marks[i] + "  ");
		}
		System.out.println();
		
		// another way of declaration and initializing array
		String cities[] = { "Chennai", "Blore", "Delhi", "Kolkatta" };

		for (String city : cities) {

			System.out.println(city + " " + city.length());
		}

	}

}
