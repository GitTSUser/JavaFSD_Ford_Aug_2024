package com.ford.java8.dateandtime;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class TimeZoneDemo1 {

	public static void setMeeting(ZonedDateTime localZone, String otherZone) {

		ZonedDateTime zonedDateTime = localZone.withZoneSameInstant(ZoneId.of(otherZone));
		System.out.println("Meeting set at " + zonedDateTime);
	}

	public static void main(String[] args) {

		ZoneId zoneId = ZoneId.systemDefault();
		System.out.println(zoneId);
		LocalDateTime meetingTime = LocalDateTime.of(2024, 9, 7, 19, 30);
		ZonedDateTime myZonedMeetingTime = ZonedDateTime.of(meetingTime, zoneId);

		System.out.println("Meeting at localtime is:" + myZonedMeetingTime);
		setMeeting(myZonedMeetingTime, "America/New_York");
		setMeeting(myZonedMeetingTime, "Europe/London");
		setMeeting(myZonedMeetingTime, "Australia/Sydney");
		setMeeting(myZonedMeetingTime, "Asia/Tokyo");
	}
}