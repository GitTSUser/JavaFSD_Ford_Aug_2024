
//program to demonstrate local date 
package com.ford.java8.dateandtime;

import java.time.LocalDate;
import java.time.Period;

public class LocalDateDemo1 {

	public static void main(String[] args) {

		LocalDate today = LocalDate.now();

		System.out.println("today date is:" + today);

		System.out.println("year is:" + today.getYear());
		System.out.println("month is:" + today.getMonthValue());
		System.out.println("day is:" + today.getDayOfMonth());

		LocalDate birthday = LocalDate.of(2003, 5, 26);

		System.out.println("Your birthday is:" + birthday);

		Period age = Period.between(birthday, today);

		System.out.print("Your age as of today is:");
		System.out.println(age.getYears() + " years, " + age.getMonths() + " months, " + age.getDays() + " days");
	}

}
