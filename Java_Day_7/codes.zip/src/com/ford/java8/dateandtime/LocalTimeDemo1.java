//program to demonstrate the LocalTime apis
package com.ford.java8.dateandtime;

import java.time.LocalTime;

public class LocalTimeDemo1 {

	public static void main(String[] args) {

		LocalTime localTime = LocalTime.now();

		System.out.println("Time is:" + localTime);

		System.out.println("Hours :" + localTime.getHour());
		System.out.println("Minutes :" + localTime.getMinute());
		System.out.println("Seconds :" + localTime.getSecond());

		LocalTime myTime = LocalTime.of(10, 30, 59);

		System.out.println("MyTime is:" + myTime);

	}
}
