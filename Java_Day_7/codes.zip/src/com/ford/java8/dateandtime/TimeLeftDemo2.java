//program to find out the time a employ left to login and howmany hours he spent working in office

package com.ford.java8.dateandtime;

import java.time.Duration;
import java.time.LocalTime;

public class TimeLeftDemo2 {

	public static void main(String[] args) {

		LocalTime loginTime = LocalTime.of(9, 30);

		LocalTime logoffTime = LocalTime.of(18, 30);

		LocalTime nowTime = LocalTime.now();

		Duration workedDuration = Duration.between(loginTime, nowTime);

		System.out.println("Time worked in office:" + workedDuration);

		System.out.println(workedDuration.toHours()+" : "+(workedDuration.toMinutes()%60));
		Duration remainingDuration = Duration.between(nowTime, logoffTime);

		System.out.println("Time left to logoff:" + remainingDuration);
		System.out.println(remainingDuration.toHours()+" : "+(remainingDuration.toMinutes()%60));

	}
}
