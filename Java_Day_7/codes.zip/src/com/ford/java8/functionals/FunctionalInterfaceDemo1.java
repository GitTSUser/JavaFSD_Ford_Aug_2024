//program to demonstrate creation of a functional interface and implementation of it

package com.ford.java8.functionals;

@FunctionalInterface
interface Greetable {

//	public void display(String name);

	public void greet(String name);

}

/*
 * class Greet implements Greetable {
 * 
 * @Override public void greet(String name) {
 * 
 * System.out.println("welcome to " + name); }
 * 
 * }
 */

public class FunctionalInterfaceDemo1 {

	public static void main(String[] args) {

		Greetable greetable = (name) -> {
			System.out.println("Welcome to " + name);
		};

		greetable.greet("Ravi");
		greetable.greet("Harry");
		
	}
}
