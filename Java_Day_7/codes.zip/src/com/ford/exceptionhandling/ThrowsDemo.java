//program to demonstrate the use of throws clause for propagating checked exceptions between methods

package com.ford.exceptionhandling;

import java.io.IOException;

public class ThrowsDemo {

	public static void m3() throws IOException, ClassNotFoundException {

		// throw new ArithmeticException("just checking un-checked exception
		// propagation"); //creation of un-checked ex obj
		if (1 == 2) {
			throw new IOException("just checking checked exception propagation");
		} else {
			throw new ClassNotFoundException("just checking multiple checked exceptions");
		}

	}

	public static void m2() throws IOException, ClassNotFoundException {
		m3(); // calling m3 method
	}

	public static void m1() throws IOException, ClassNotFoundException {
		m2(); // calling m2 method
	}

	public static void main(String[] args)  {
		try {
		m1(); // calling m1 method
		}catch(Exception exception) {
			System.out.println("exception is:"+exception.getMessage());
		}
	}
}