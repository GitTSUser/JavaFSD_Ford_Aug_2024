//program to demonstrate the execution of finally block incase of exception or no-exception or having return statement

package com.ford.exceptionhandling;

public class FinallyDemo {

	// incase of exception
	public static void m1() {
		System.out.println("method m1() started");
		try {
			throw new ArithmeticException("arithmetic exception raised");
		} catch (ArithmeticException exception) {
			System.out.println("catch exception in m1() method:" + exception.getMessage());
		} finally {
			System.out.println("finally executed in m1() method");
		}
		System.out.println("method m1() ends");

	}

	// incase of no exception
	public static void m2() {
		System.out.println("method m2() started");
		try {
		} catch (ArithmeticException exception) {
			System.out.println("catch exception in m2() method:" + exception.getMessage());
		} finally {
			System.out.println("finally block executed in m2() method");
		}
		System.out.println("method m2() ends");
	}

	// incase of return statement
	public static void m3() {
		System.out.println("method m3() started");
		try {
			return;
		} catch (ArithmeticException exception) {
			System.out.println("catch exception in m3() method:" + exception.getMessage());
		} finally {
			System.out.println("finally block executed in m3() method");
		}
		System.out.println("method m3() ends");
	}

	public static void main(String[] args) {

		m1();
		System.out.println("---------------");
		m2();
		System.out.println("----------------");
		m3();
	}
}