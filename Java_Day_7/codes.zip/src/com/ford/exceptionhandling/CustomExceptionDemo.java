//program to demonstrate custom exception creation and usage
package com.ford.exceptionhandling;

class Account {
	private static long accountNo = 123344555;
	private String holderName;
	private double balance;

	public Account(String holderName, double balance) {
		super();
		accountNo++;
		this.holderName = holderName;
		this.balance = balance;
	}

	public String accountInfo() {
		return "Account [accountNo=" + accountNo + ", holderName=" + holderName + ", balance=" + balance + "]";
	}

}

class InvalidDetailsToOpenAccountException extends RuntimeException {
	private String message;

	public InvalidDetailsToOpenAccountException(String msg) {
		super(msg);
		this.message = msg;
	}

	@Override
	public String toString() {
		return message;
	}
}

class ABCBank {
	public static String openAccount(String name, int age, double balance) {
		if (age > 18 && balance >= 1000) {
			return new Account(name, balance).accountInfo();
		}
		throw new InvalidDetailsToOpenAccountException("Account cannot be opened!");
	}
}

public class CustomExceptionDemo {
	public static void main(String[] args) {
		try {
			String info = ABCBank.openAccount("arunkuamr", 20, 500);
			System.out.println(info);
		} catch (InvalidDetailsToOpenAccountException exception) {
			System.out.println("exception is:" + exception.getMessage());
		}

	}
}