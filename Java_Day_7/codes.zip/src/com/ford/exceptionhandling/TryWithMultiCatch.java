package com.ford.exceptionhandling;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryWithMultiCatch {

	public static void main(String[] args) {

		boolean flag = false;
		Scanner scanner = new Scanner(System.in);
		do {

			try {
				System.out.println("enter a num:");
				int x = scanner.nextInt();
				System.out.println("enter another num:");
				int y = scanner.nextInt();
				int r = x / y;
				System.out.println("result is:" + r);
				flag = true;
			} catch (ArithmeticException | InputMismatchException exception) {
				System.out.println("exception is:" + exception.getMessage());
				flag = false;
			}
			System.out.println("program ends");

		} while (flag == false);

		scanner.close();
	}
}