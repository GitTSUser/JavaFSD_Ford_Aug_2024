
//program to perform Txns on a bank account
package com.ford.oops;

class BankAccount {

	private int accountNo;
	private String accountHolder;
	private double accountBalance;

	//setter methods: to update data in object
	public void setAccountNo(int acntNo) {
		accountNo = acntNo;
	}

	public void setAccountHolder(String acntHolder) {
		accountHolder = acntHolder;
	}

	public void setAccountBalance(double acntBalance) {
		accountBalance = acntBalance;
	}

	//getter methods: to get the data from object
	public int getAccountNo() {
		return accountNo;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public double getAccountBalance() {
		return accountBalance;
	}


	// business methods: perform business operations
	public void deposit(double amount) {

		System.out.println("before deposit, balance is:" + accountBalance);
		accountBalance = accountBalance + amount;
		System.out.println("after deposit, balance is:" + accountBalance);
	}

	public void withdraw(double amount) {

		System.out.println("before withdraw, balance is:" + accountBalance);
		accountBalance = accountBalance - amount;
		System.out.println("after withdraw, balance is:" + accountBalance);
	}

	public void transfer(int acntNo, double amountToTransfer) {

		if (accountBalance > amountToTransfer) {
			accountBalance = accountBalance - amountToTransfer;
			System.out.println("amount " + amountToTransfer + " transferred to account:" + acntNo);
			System.out.println("after transfer, balance is:" + accountBalance);
		} else {
			System.out.println("insufficient funds to transfer!");
		}
	}
	

}

public class BankingTxns {

	public static void main(String[] args) {
		
		
		BankAccount acnt=new BankAccount();
		acnt.setAccountNo(12345678);
		acnt.setAccountHolder("Vinodh Kumar");
		acnt.setAccountBalance(45000);
		
	
		System.out.println("Account details:");
		System.out.println("account no:"+acnt.getAccountNo()+"  account holder:"+acnt.getAccountHolder());
		System.out.println("Balance is:"+acnt.getAccountBalance());
				
		
		acnt.withdraw(12000);
		acnt.deposit(6000);
		acnt.transfer(2345678, 45000);			

	}
}
