// program to demonstrate the use of a constructor

package com.ford.oops;

import java.util.Arrays;

class FordEmploy {

	private int id;
	private String name;
	private double salary;
	private String role;
	private String email;
	private String projects[];
	private String department;

	//zero-arg constructor
	public FordEmploy() {

		this.id = 1001;
		this.name = "arun kumar";
		this.salary = 45000.25;
		this.role = "Java Developer";
		this.email = "arun@yahoo.com";
		this.projects = new String[] { "BCMS", "CMS", "Accudose" };
		this.department = "IT";

	}

	public String getFordEmployInfo() {

		return this.id + " " + this.name + " " + this.salary + " " + this.role + " " + this.email + " " +Arrays.toString( this.projects)
				+ " " + this.department;
	}

}

public class ConstructorDemo {

	public static void main(String[] args) {

		FordEmploy fordEmploy = new FordEmploy();
		FordEmploy fordEmploy2 = new FordEmploy();
		FordEmploy fordEmploy3 = new FordEmploy();

		System.out.println("Employ-1 is:" + fordEmploy.getFordEmployInfo());
		System.out.println("Employ-2 is:" + fordEmploy2.getFordEmployInfo());
		System.out.println("Employ-3 is:" + fordEmploy3.getFordEmployInfo());
	}
}