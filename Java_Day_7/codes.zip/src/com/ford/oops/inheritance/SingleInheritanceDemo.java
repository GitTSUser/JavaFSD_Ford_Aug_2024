//program to demonstrate single inheritance

package com.ford.oops.inheritance;

class Vehicle {

	private int regNo;
	private int noOfWheels;
	private String color;
	private String brand;
	private double price;
	private String vehicleType;

	public Vehicle(int regNo, int noOfWheels, String color, String brand, double price, String vehicleType) {
		this.regNo = regNo;
		this.noOfWheels = noOfWheels;
		this.color = color;
		this.brand = brand;
		this.price = price;
		this.vehicleType = vehicleType;
	}

	public int getRegNo() {
		return regNo;
	}

	public int getNoOfWheels() {
		return noOfWheels;
	}

	public String getColor() {
		return color;
	}

	public String getBrand() {
		return brand;
	}

	public double getPrice() {
		return price;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public String vehicleInfo() {
		return this.regNo + " " + this.brand + " " + this.color + " " + this.price + " " + this.vehicleType + " "
				+ this.noOfWheels;
	}

}

class Car extends Vehicle {

	int seatingCapacity;
	int speedReading;
	String gearType;

	public Car(int regNo, int noOfWheels, String color, String brand, double price, String vehicleType,
			int seatingCapacity, int speedReading, String gearType) {

		super(regNo, noOfWheels, color, brand, price, vehicleType);
		this.seatingCapacity = seatingCapacity;
		this.speedReading = speedReading;
		this.gearType = gearType;

	}
	
	public String carInfo() {
		return this.vehicleInfo()+" "+this.seatingCapacity+" "+this.speedReading+" "+this.gearType;
	}

}

public class SingleInheritanceDemo {

	public static void main(String[] args) {

		Car car = new Car(1234, 4, "Blue", "Maruthi", 85000.25, "petrol",4,1000,"manual");
		System.out.println("Vehicle is:" + car.carInfo());
	}

}
