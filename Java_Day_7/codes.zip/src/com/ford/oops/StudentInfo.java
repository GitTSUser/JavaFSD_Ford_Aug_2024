//program to demonstrate the encapsulation 

package com.ford.oops;

class Student {

	private int id;
	private String name;
	private String branch;
	private int yearOfStudy;

	// setter methods
	public void setId(int studentId) {
		if(studentId<0) {
			throw new RuntimeException("Id must be a non-negative!");
		}
		this.id = studentId;
	}

	public void setName(String studentName) {
		this.name = studentName;
	}

	public void setBranch(String studentBranch) {
		this.branch = studentBranch;
	}

	public void setYearOfStudy(int yos) {
		
		if(yos<1 || yos>4) {
			throw new RuntimeException("Year of study must be between 1-4");
		}
		
		this.yearOfStudy = yos;
	}

	// getter methods

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public String getBranch() {
		return this.branch;
	}

	public int getYearOfStudy() {
		return this.yearOfStudy;
	}

}

public class StudentInfo {

	public static void main(String[] args) {

		Student s1 = new Student();

		s1.setId(125);
		s1.setName("Nandhan");
		s1.setBranch("TSE");
		s1.setYearOfStudy(1);

		System.out.println(s1.getId() + " " + s1.getName() + " " + s1.getBranch() + "  " + s1.getYearOfStudy());

	}
}
