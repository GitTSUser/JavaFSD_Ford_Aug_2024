//program to demonstrate parameterized constructor

package com.ford.oops;

import java.util.Arrays;

class FordEmployee {

	private int id;
	private String name;
	private double salary;
	private String role;
	private String email;
	private String projects[];
	private String department;

	// zero-arg constructor

	public FordEmployee() {
		System.out.println("FordEmployee.FordEmployee()");
	}

	public FordEmployee(int id) {
		this();
		System.out.println("FordEmployee.FordEmployee(id)");
		this.id = id;

	}

	public FordEmployee(int id, String name) {
		this(id);
		System.out.println("FordEmployee.FordEmployee(id,name)");
		this.name = name;

	}

	public FordEmployee(int id, String name, double salary) {
		this(id, name);
		System.out.println("FordEmployee.FordEmployee(id,name,salary)");
		this.salary = salary;
	}

	public FordEmployee(int id, String name, double salary, String role) {
		this(id, name, salary);
		System.out.println("FordEmployee.FordEmployee(id,name,salary,role)");
		this.role = role;
	}

	public FordEmployee(int id, String name, double salary, String role, String email) {
		this(id, name, salary, role);
		System.out.println("FordEmployee.FordEmployee(id,name,salary,role,email)");
		this.email = email;
	}

	public FordEmployee(int id, String name, double salary, String role, String email, String projects[]) {

		this(id, name, salary, role, email);
		System.out.println("FordEmployee.FordEmployee(id,name,salary,role,email,projects)");
		this.projects = projects;
	}

	public FordEmployee(int id, String name, double salary, String role, String email, String projects[],
			String department) {
		this(id, name, salary, role, email, projects);
		System.out.println("FordEmployee.FordEmployee(id,name,salary,role,email,projects,dept)");
		this.department = department;

	}
	
	

	public String getFordEmployInfo() {

		return this.id + " " + this.name + " " + this.salary + " " + this.role + " " + this.email + " "
				+ Arrays.toString(this.projects) + " " + this.department;
	}

}

public class ParameterizedConstructor {

	public static void main(String[] args) {

	/*	FordEmployee emp1 = new FordEmployee();
		System.out.println(emp1.getFordEmployInfo());

		FordEmployee emp2 = new FordEmployee(1001);
		System.out.println(emp2.getFordEmployInfo());

		FordEmployee emp3 = new FordEmployee(1001, "arun");
		System.out.println(emp3.getFordEmployInfo());

		FordEmployee emp4 = new FordEmployee(1002, "varun", 45000.25);
		System.out.println(emp4.getFordEmployInfo());

		FordEmployee emp5 = new FordEmployee(1003, "karun", 65000.25, "Developer");
		System.out.println(emp5.getFordEmployInfo());
*/
		
		
		FordEmployee emp=new FordEmployee(1001,"arun",65000.25,"Dev","arun@y.com",new String[] {"CMS","BMS"},"IT");
		
		System.out.println(emp.getFordEmployInfo());
		
		
	}
}
