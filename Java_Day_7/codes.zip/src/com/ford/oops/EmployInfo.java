
//program to demonstrate creation of objects to hold the ford employees data

package com.ford.oops;

class Employ {

	int id;
	String name;
	String email;
	String phone;
	String role;
	double salary;
	char gender;
	String dob;
	String department;
}

public class EmployInfo {

	public static void main(String[] args) {

		Employ e1 = new Employ();

		e1.id = 1100;
		e1.name = "arun kumar";
		e1.email = "arun@yahoo.com";
		e1.phone = "45604522";
		e1.role = "Java Developer";
		e1.salary = 45000.25;
		e1.gender = 'm';
		e1.dob = "15-08-2001";
		e1.department = "IT";

		System.out.println("Employ-1 details:");
		System.out.println("id is:" + e1.id);
		System.out.println("name is:" + e1.name);
		System.out.println("email is:" + e1.email);
		System.out.println("phone is:" + e1.phone);
		System.out.println("role is:" + e1.role);
		System.out.println("salary is:" + e1.salary);

		// update role and salary of an employ
		e1.role = "Team Lead";
		e1.salary = 95000.45;

		System.out.println("After update, Employ-1 details:");
		System.out.println("id is:" + e1.id);
		System.out.println("name is:" + e1.name);
		System.out.println("email is:" + e1.email);
		System.out.println("phone is:" + e1.phone);
		System.out.println("role is:" + e1.role);
		System.out.println("salary is:" + e1.salary);

		Employ e2 = e1;
		e2.id = 1002;
		e2.name = "varun";
		System.out.println("------------------------");
		System.out.println("Employ-2 details:");
		System.out.println("id is:" + e2.id);
		System.out.println("name is:" + e2.name);
		System.out.println("email is:" + e2.email);
		System.out.println("phone is:" + e2.phone);
		System.out.println("role is:" + e2.role);
		System.out.println("salary is:" + e2.salary);

		System.out.println("===============");
		System.out.println("id is:" + e1.id);
		System.out.println("name is:" + e1.name);
		System.out.println("email is:" + e1.email);
		System.out.println("phone is:" + e1.phone);
		System.out.println("role is:" + e1.role);
		System.out.println("salary is:" + e1.salary);

	}

}
