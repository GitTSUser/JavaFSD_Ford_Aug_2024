package com.ford.oops.staticmembers;

import java.util.Date;

class Product {

	private int serialNo;
	private String name;
	private double price;
	private static String seller;
	private boolean isAuthorized;
	private Date dateOfManufacture;

	static {
		System.out.println("Product.static block{}");
		seller = "Amazon";
	}

	{ //non-static block usage
		System.out.println("Product.non-static block{}");
		this.isAuthorized = true;
		this.dateOfManufacture = new Date(System.currentTimeMillis());
	}
	
	public Product(int serialNo, String name, double price) {
		System.out.println("Product.Product() constructor called");
		this.name = name;
		this.serialNo = serialNo;
		this.price = price;
	}

	public String getProductInfo() {
		return this.serialNo + " " + this.name + "  "+this.dateOfManufacture+" " + this.price + "  " + seller + " " + this.isAuthorized;
	}

}

public class StaticDemo1 {

	public static void main(String[] args) {

		Product product1 = new Product(1234, "fan", 4500.25);
		System.out.println(product1.getProductInfo());

		Product product2 = new Product(2234, "lappy", 55000.25);
		System.out.println(product2.getProductInfo());

		Product product3 = new Product(2235, "mouse", 500.25);
		System.out.println(product3.getProductInfo());

	}
}
