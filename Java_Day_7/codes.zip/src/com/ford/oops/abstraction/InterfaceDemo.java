//program to demonstrate the use of interface

package com.ford.oops.abstraction;

interface Vehicle {

	public abstract void start();

	public abstract void move();

	void stop();

}

class Bike implements Vehicle {

	@Override
	public void start() {
		System.out.println("Bike.start()");

	}

	@Override
	public void move() {
		System.out.println("Bike.move()");
	}

	@Override
	public void stop() {
		System.out.println("Bike.stop()");
	}
}

class Car implements Vehicle {

	@Override
	public void start() {
		System.out.println("Car.start()");
	}

	@Override
	public void move() {
		System.out.println("Car.move()");

	}

	@Override
	public void stop() {
		System.out.println("Car.stop()");
	}
}

public class InterfaceDemo {

	public static void main(String[] args) {
		Vehicle vehicle;

		vehicle = new Car();
		vehicle.start();
		vehicle.move();
		vehicle.stop();

		vehicle = new Bike();
		vehicle.start();
		vehicle.move();
		vehicle.stop();

	}

}
