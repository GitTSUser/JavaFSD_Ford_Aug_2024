package com.ford.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "companies")
public class Company {

    @Id
    private Integer regNo;
    private String name;
    private String location;
    private String ceo;
    private LocalDate established;

    @OneToMany(cascade = CascadeType.ALL)
    private Set<Employ> employees;

    public Company(String name, String location, String ceo, LocalDate established, Set<Employ> employees) {
        this.name = name;
        this.location = location;
        this.ceo = ceo;
        this.established = established;
        this.employees = employees;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Company company)) return false;
        return regNo == company.regNo && Objects.equals(name, company.name) && Objects.equals(location, company.location) && Objects.equals(ceo, company.ceo) && Objects.equals(established, company.established) && Objects.equals(employees, company.employees);
    }

    @Override
    public int hashCode() {
        return Objects.hash(regNo, name, location, ceo, established, employees);
    }
}
