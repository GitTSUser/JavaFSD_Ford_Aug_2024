package com.ford.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "employees")
public class Employ {

    @Id
    private Integer id;
    private String name;
    private Double salary;
    private String designation;
    private LocalDate joinedDate;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employ employ)) return false;
        return id == employ.id && Double.compare(salary, employ.salary) == 0 && Objects.equals(name, employ.name) && Objects.equals(designation, employ.designation) && Objects.equals(joinedDate, employ.joinedDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, salary, designation, joinedDate);
    }

    public Employ(String name, double salary, String designation, LocalDate joinedDate) {
        this.name = name;
        this.salary = salary;
        this.designation = designation;
        this.joinedDate = joinedDate;
    }
}
