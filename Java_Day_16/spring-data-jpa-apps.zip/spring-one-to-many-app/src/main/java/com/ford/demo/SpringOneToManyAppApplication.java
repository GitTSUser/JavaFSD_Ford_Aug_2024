package com.ford.demo;

import com.ford.demo.entity.Company;
import com.ford.demo.entity.Employ;
import com.ford.demo.repository.ICompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@SpringBootApplication
public class SpringOneToManyAppApplication implements CommandLineRunner {

	@Autowired
	private ICompanyRepository	companyRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringOneToManyAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		addCompanyInfo();

	}

	private void addCompanyInfo() {

		Employ e1=new Employ(100,"arun",85000.25,"Java Developer", LocalDate.of(2018,6,18));
		Employ e2=new Employ(200,"varun",75000.25,".NET Developer", LocalDate.of(2022,11,25));
		Employ e3=new Employ(300,"tarun",65000.35,"UI Developer", LocalDate.of(2010,7,10));
		Employ e4=new Employ(400,"karun",95000.35,"Web Developer", LocalDate.of(2015,12,4));

		Set<Employ> employList=new HashSet<>();
		employList.add(e1);
		employList.add(e2);
		employList.add(e3);
		employList.add(e4);


		Company company = new Company(1234567,"Ford","Karapakkam","Jim Farley", LocalDate.of(1903,6,16),employList);

		Company savedCompany=companyRepository.save(company);

		if(savedCompany!=null){
			System.out.println("company details saved in DB");
		}else {
			System.out.println("company details not saved in DB");
		}
	}
}