package com.ford.demo.entity.service;

import com.ford.demo.entity.Company;

import java.util.List;

public interface ICompanyService {
    public Company addCompany(Company company) ;
    public Company getCompanyById(int id);
    public List<Company> getAllCompanies();
    public Company updateCompany(Company company);
    public boolean deleteCompany(int id);
}
