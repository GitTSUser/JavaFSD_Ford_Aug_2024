package com.ford.demo.entity.service;

import com.ford.demo.entity.Company;
import com.ford.demo.repository.ICompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CompanyServiceImpl implements ICompanyService{

    @Autowired
    private ICompanyRepository repository;

    @Override
    public Company addCompany(Company company) {

        return repository.save(company);
    }

    @Override
    public Company getCompanyById(int id) {
        return  repository.findById(id).get();
    }

    @Override
    public List<Company> getAllCompanies() {
        List<Company> companyList=new ArrayList<Company>();
        Iterable<Company> iterable= repository.findAll();
        for(Company company:iterable){
            companyList.add(company);
        }
        return companyList;
    }

    @Override
    public Company updateCompany(Company company) {
        return repository.save(company);
    }

    @Override
    public boolean deleteCompany(int id) {
        repository.deleteById(id);

        if(repository.existsById(id)){
            return true;
        }

        return false;
    }
}