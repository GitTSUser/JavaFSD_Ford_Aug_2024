package com.ford.demo;

import com.ford.demo.entity.Company;
import com.ford.demo.entity.service.ICompanyService;
import com.ford.demo.repository.ICompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class SpringJpaAppOneApplication  implements CommandLineRunner {

	@Autowired
	ICompanyService companyService;

	@Autowired
	ICompanyRepository companyRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaAppOneApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	addCompany();
	//findCompany(1);
	//deleteCompany(3);
		printAllCompanies();
	//findCompanyByIdAndName(2,"TCS");
	//findCompanyWithNameAndLocation("Ford","Karapakkam");
	//findCompanyWithNameAndLocationAndCeo("Ford","Karapakkam","Jim Farley");
//	findCompaniesWithLocation("Siruseri");
	//findCompaniesWithNameOrLocation("Ford","Gundy");
	findCompaniesAgeBetween(10,20);
	}

	private void findCompaniesAgeBetween(int i, int i1) {
	List<Company> companyList=companyRepository.findByAgeBetween(i,i1);

		System.out.println("search by age between:");
		companyList.forEach(System.out::println);
	}

	public void findCompaniesWithNameOrLocation(String cname,String location){
		List<Company> companyList=companyRepository.findByNameOrLocation(cname,location);

		System.out.println("search by name or loc:");
		companyList.forEach(System.out::println);
	}
	public void findCompaniesWithLocation(String location) {
		List<Company> companyList=companyRepository.findByLocation(location);

		System.out.println("companies by location: "+companyList);
	}

	private void findCompanyWithNameAndLocationAndCeo(String company, String location, String ceo) {

	Company company1=	companyRepository.findByNameAndLocationAndCeo(company, location, ceo);

		System.out.println("search by name,loc,ceo is:"+company1);
	}

	private void findCompanyWithNameAndLocation(String company, String location) {

		Company company1=companyRepository.findByNameAndLocation(company,location);

		System.out.println("search by name and location is:"+company1);

	}

	void printAllCompanies(){
		System.out.println("All companies::");
		companyRepository.findAll().forEach(System.out::println);
	}

	void findCompanyByIdAndName(Integer regNo,String name){
		Company company=companyRepository.findByRegNoAndName(regNo,name);
		System.out.println("searching by regNo,name is:"+company);
	}

	public void deleteCompany(int id) {
		if(companyService.deleteCompany(id)){
			System.out.println("company deleted successfully");
		}else{
			System.out.println("company deletion failed");
		}

		System.out.println("after delete, available companies::");
		companyService.getAllCompanies().forEach(System.out::println);
	}

	public void findCompany(int regNo){
		Company company=companyService.getCompanyById(regNo);
		System.out.println("company found is:"+company);
		System.out.println("---------------------------------");
		List<Company> companyList=companyService.getAllCompanies();
		System.out.println("All Companies::");
		companyList.forEach(System.out::println);

	}

	public void addCompany(){
		Company company1=new Company(123456,"Ford","Karapakkam","Jim Farley",12);
		Company company2=new Company(123457,"TCS","Siruseri","TCS CEO",5);
		Company company3=new Company(123458,"CTS","Siruseri","S. Ravi Kumar",7);
		Company company4=new Company(123459,"Wipro","Gundy","Premji",20);


		Company savedCompany=companyService.addCompany(company1);
		Company savedCompany2=companyService.addCompany(company2);
		Company savedCompany3=companyService.addCompany(company3);
		Company savedCompany4=companyService.addCompany(company4);
		if(savedCompany!=null) {
			System.out.println("company saved in db");
		}else{
			System.out.println("company not saved in db");
		}
	}

}