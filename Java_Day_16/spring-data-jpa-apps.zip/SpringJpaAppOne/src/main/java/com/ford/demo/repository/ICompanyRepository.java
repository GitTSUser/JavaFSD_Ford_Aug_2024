package com.ford.demo.repository;

import com.ford.demo.entity.Company;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ICompanyRepository extends CrudRepository<Company, Integer> {

    Company save(Company entity);
    Optional<Company> findById(Integer id);
    Iterable<Company> findAll();
    void deleteById(Integer id);
    void delete(Company entity);

    Company findByRegNoAndName(Integer regNo, String name);

    Company findByNameAndLocation(String name,String location);

    Company findByNameAndLocationAndCeo(String name,String location,String ceo);

    List<Company> findByLocation(String location);

    List<Company> findByNameOrLocation(String name,String location);

    List<Company> findByAgeBetween(Integer startAge,Integer endAge);

}