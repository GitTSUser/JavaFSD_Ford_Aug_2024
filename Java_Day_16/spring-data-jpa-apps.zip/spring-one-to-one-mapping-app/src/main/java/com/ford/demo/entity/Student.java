package com.ford.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Cascade;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String name;
    private String phone;

    @OneToOne(cascade = CascadeType.ALL)
    private Course course;

    public Student(String name, String phone, Course course) {
        this.name = name;
        this.phone = phone;
        this.course = course;
    }
}
