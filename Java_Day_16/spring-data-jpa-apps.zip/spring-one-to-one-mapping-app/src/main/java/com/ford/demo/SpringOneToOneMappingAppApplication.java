package com.ford.demo;

import com.ford.demo.entity.Course;
import com.ford.demo.entity.Student;
import com.ford.demo.repository.IStudentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class SpringOneToOneMappingAppApplication implements CommandLineRunner {

    @Autowired
    private IStudentRepository studentRepository;

    public static void main(String[] args) {
        SpringApplication.run(SpringOneToOneMappingAppApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        addStudents();
        findStudents();
        findStudentsCourseByName();
    }

    public void findStudentsCourseByName(){
        Student student=studentRepository.findByCourseName("CSE");

        System.out.println("CSE student is:"+student);
    }

    public void findStudents() {
        List<Student> students = studentRepository.findAll();

        for (Student student : students) {
        //    System.out.println(student);
            System.out.println(student.getId()+" "+student.getName()+" "+student.getCourse().getName()+" "+student.getCourse().getFee());
        }

    }


    public void addStudents() {
        Course c1 = new Course("CSE", "computer science and engineering", 85000.25);
        Student s1 = new Student( "Vijay", "044-253346", c1);
        Course c2 = new Course("EEE", "Engg Enngg engineering", 75000.25);
        Student s2 = new Student( "Rajini", "044-253346", c2);
        Course c3= new Course("IT", "Information Technology", 95000.25);
        Student s3 = new Student( "Vijay", "044-253346", c3);

        Student savedStudent = studentRepository.save(s1);
        Student savedStudent2=studentRepository.save(s2);
        Student savedStudent3=studentRepository.save(s3);
        if (savedStudent != null)
            System.out.println("student saved in db");
        else
            System.out.println("student not saved in db");
    }
}
